# ASM Configuration

ASM is configured with environment variables.

## Required

| Variable | Description |
|---|---|
| `LOGIN_URL` | Acumatica login URL |
| `URL` | Target URL after login |
| `LOGIN_USER` | Monitoring username |
| `LOGIN_PASS` | Monitoring password |

## Readiness

| Variable | Default | Description |
|---|---:|---|
| `READY_SELECTOR` | `.navbar-header` | Element that indicates the UI shell is present |
| `READY_TIMEOUT_MS` | `30000` | Maximum wait for the ready selector |
| `READY_IDLE_MS` | `2000` | Extra wait after selector appears |

## Scoring

| Variable | Default |
|---|---:|
| `EXPERIENCE_GOOD_MS` | `7000` |
| `EXPERIENCE_BAD_MS` | `20000` |
| `LOGIN_GOOD_MS` | `3000` |
| `LOGIN_BAD_MS` | `10000` |
| `APP_GOOD_MS` | `4000` |
| `APP_BAD_MS` | `12000` |
| `UI_GOOD_MS` | `2000` |
| `UI_BAD_MS` | `6000` |
