# Troubleshooting ASM

## The exporter starts, but `/metrics` is empty

Check container logs:

```bash
docker logs acumatica-synthetic-monitor
```

Common causes:

- Wrong `LOGIN_URL`
- Wrong username/password
- Selector changed
- Acumatica login flow changed
- Container cannot reach Acumatica

## Login fails

Confirm these selectors still exist:

- `#txtUser`
- `#txtPass`
- `#btnLogin`

If your Acumatica login page uses different selectors, update `src/login.js`.

## UI ready fails

ASM waits for `.navbar-header` by default.

If Acumatica changes or your site uses a different shell selector, update this in `.env`:

```text
READY_SELECTOR=.navbar-header
```

## Capture screenshots

Set:

```text
DEBUG_SCREENSHOT=true
SCREENSHOT_ON_FAILURE=true
```

Screenshots will be saved to the `screenshots/` directory.
