# Acumatica Synthetic Monitor (ASM)

**Acumatica Synthetic Monitor (ASM)** is a lightweight synthetic monitoring exporter for Acumatica ERP.

ASM logs into Acumatica like a real user, waits for the application shell to become usable, measures the user journey, calculates an experience score, and exposes Prometheus metrics for Grafana dashboards and alerting.

## What ASM measures

ASM measures the experience from the user's perspective:

- Login page load time
- Login form fill time
- Authentication / login submit time
- Application load time
- UI ready time
- Total journey time
- Experience score
- Diagnostic login/app/UI scores
- Frame count
- HTTP request count
- Failed HTTP request count
- Console error count

## Quick start

1. Copy `.env.example` to `.env`.

```bash
cp .env.example .env
```

2. Edit `.env` with your Acumatica URL and monitoring credentials.

3. Build and start the container.

```bash
docker compose up -d --build
```

4. Test the exporter.

```bash
curl http://localhost:9442/
curl http://localhost:9442/metrics
```

## Prometheus scrape config

```yaml
scrape_configs:
  - job_name: "acumatica-synthetic-monitor"
    metrics_path: /metrics
    static_configs:
      - targets: ["asm-host:9442"]
```

## Main metrics

| Metric | Meaning |
|---|---|
| `asm_experience_score` | Overall user experience score from 0–100 |
| `asm_login_score` | Diagnostic score for authentication |
| `asm_app_score` | Diagnostic score for app loading |
| `asm_ui_score` | Diagnostic score for UI readiness |
| `asm_total_time_ms` | End-to-end synthetic journey time |
| `asm_login_page_load_ms` | Login page load time |
| `asm_login_fill_ms` | Time to fill login form |
| `asm_login_submit_ms` | Time after clicking login until navigation settles |
| `asm_app_load_ms` | Time to load the Acumatica target URL |
| `asm_ui_ready_ms` | Time to wait for the ready selector and idle buffer |
| `asm_frame_count` | Number of browser frames detected |
| `asm_request_count` | Total HTTP responses observed |
| `asm_failed_request_count` | HTTP responses with status >= 400 |
| `asm_console_error_count` | Browser console errors detected |
| `asm_last_run_success` | 1 if the last run succeeded, 0 if it failed |

## Experience score

The headline score is based primarily on total journey time because that best matches what a user feels.

Default scoring:

- 7 seconds or less = 100
- 20 seconds or more = 0
- Between those values = scaled linearly

Diagnostic scores are also exported for login, app load, and UI readiness.

## Troubleshooting

See `docs/Troubleshooting.md`.
