const { sleep } = require('../src/timing');

async function runHomeJourney(page, config, timing, logger) {
  await timing.timeStep('appLoadMs', async () => {
    await page.goto(config.targetUrl, { waitUntil: 'networkidle2' });
  }, timing.timings, logger);

  await timing.timeStep('uiReadyMs', async () => {
    await page.waitForSelector(config.readySelector, {
      visible: true,
      timeout: config.readyTimeoutMs
    });
    await sleep(config.readyIdleMs);
  }, timing.timings, logger);

  return { frameCount: page.frames().length };
}

module.exports = { name: 'home', run: runHomeJourney };
