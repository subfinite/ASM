async function loginToAcumatica(page, config, timing, logger) {
  await timing.timeStep('loginPageLoadMs', async () => {
    await page.goto(config.loginUrl, { waitUntil: 'networkidle2' });
  }, timing.timings, logger);

  await timing.timeStep('loginFillMs', async () => {
    await page.waitForSelector('#txtUser', { visible: true, timeout: 30000 });
    await page.type('#txtUser', config.username);
    await page.waitForSelector('#txtPass', { visible: true, timeout: 30000 });
    await page.type('#txtPass', config.password);
  }, timing.timings, logger);

  await timing.timeStep('loginSubmitMs', async () => {
    await Promise.all([
      page.click('#btnLogin'),
      page.waitForNavigation({ waitUntil: 'networkidle2' })
    ]);
  }, timing.timings, logger);
}

module.exports = { loginToAcumatica };
