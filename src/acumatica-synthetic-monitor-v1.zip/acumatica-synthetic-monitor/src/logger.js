function timestamp() { return new Date().toISOString(); }
function info(message, data) {
  if (data !== undefined) console.log(`[${timestamp()}] INFO ${message}`, data);
  else console.log(`[${timestamp()}] INFO ${message}`);
}
function error(message, err) {
  if (err) console.error(`[${timestamp()}] ERROR ${message}`, err);
  else console.error(`[${timestamp()}] ERROR ${message}`);
}
module.exports = { info, error };
