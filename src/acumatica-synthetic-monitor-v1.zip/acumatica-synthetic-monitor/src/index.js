const http = require('http');
const { config, validateConfig } = require('./config');
const { runSynthetic } = require('./runner');
const logger = require('./logger');

process.on('unhandledRejection', (err) => { logger.error('Unhandled rejection', err); });

try { validateConfig(); }
catch (err) { logger.error(err.message); process.exit(1); }

http.createServer(async (req, res) => {
  if (req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('ASM OK
');
    return;
  }
  if (req.url !== '/metrics') {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found
');
    return;
  }
  try {
    const metrics = await runSynthetic(config);
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
    res.end(metrics + '
');
  } catch (err) {
    logger.error('Unexpected /metrics failure', err);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('ASM metrics collection failed
');
  }
}).listen(config.port, () => { logger.info(`ASM listening on port ${config.port}`); });
