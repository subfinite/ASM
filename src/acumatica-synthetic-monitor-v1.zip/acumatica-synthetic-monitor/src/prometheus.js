function escapeLabelValue(value) {
  return String(value).replace(/\/g, '\\').replace(/
/g, '\n').replace(/"/g, '\"');
}

class PrometheusBuilder {
  constructor(defaultLabels = {}) {
    this.lines = [];
    this.defaultLabels = defaultLabels;
    this.seen = new Set();
  }
  labels(extraLabels = {}) {
    const merged = { ...this.defaultLabels, ...extraLabels };
    const keys = Object.keys(merged);
    if (!keys.length) return '';
    return '{' + keys.map((key) => `${key}="${escapeLabelValue(merged[key])}"`).join(',') + '}';
  }
  gauge(name, help, value, labels = {}) {
    if (!this.seen.has(name)) {
      this.lines.push(`# HELP ${name} ${help}`);
      this.lines.push(`# TYPE ${name} gauge`);
      this.seen.add(name);
    }
    this.lines.push(`${name}${this.labels(labels)} ${Number(value)}`);
  }
  output() { return this.lines.join('
'); }
}

module.exports = { PrometheusBuilder };
