require('dotenv').config();

function numberEnv(name, fallback) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  const parsed = parseInt(raw, 10);
  return Number.isNaN(parsed) ? fallback : parsed;
}

function boolEnv(name, fallback = false) {
  const raw = process.env[name];
  if (raw === undefined || raw === '') return fallback;
  return ['true', '1', 'yes', 'y'].includes(String(raw).toLowerCase());
}

const config = {
  port: numberEnv('PORT', 9442),
  acumatica: {
    loginUrl: process.env.LOGIN_URL || process.env.URL,
    targetUrl: process.env.URL,
    username: process.env.LOGIN_USER,
    password: process.env.LOGIN_PASS,
    readySelector: process.env.READY_SELECTOR || '.navbar-header',
    readyTimeoutMs: numberEnv('READY_TIMEOUT_MS', 30000),
    readyIdleMs: numberEnv('READY_IDLE_MS', 2000)
  },
  screenshots: {
    debug: boolEnv('DEBUG_SCREENSHOT', false),
    onFailure: boolEnv('SCREENSHOT_ON_FAILURE', true),
    directory: process.env.SCREENSHOT_DIR || 'screenshots'
  },
  scoring: {
    experienceGoodMs: numberEnv('EXPERIENCE_GOOD_MS', 7000),
    experienceBadMs: numberEnv('EXPERIENCE_BAD_MS', 20000),
    loginGoodMs: numberEnv('LOGIN_GOOD_MS', 3000),
    loginBadMs: numberEnv('LOGIN_BAD_MS', 10000),
    appGoodMs: numberEnv('APP_GOOD_MS', 4000),
    appBadMs: numberEnv('APP_BAD_MS', 12000),
    uiGoodMs: numberEnv('UI_GOOD_MS', 2000),
    uiBadMs: numberEnv('UI_BAD_MS', 6000)
  }
};

function validateConfig() {
  const missing = [];
  if (!config.acumatica.loginUrl) missing.push('LOGIN_URL or URL');
  if (!config.acumatica.targetUrl) missing.push('URL');
  if (!config.acumatica.username) missing.push('LOGIN_USER');
  if (!config.acumatica.password) missing.push('LOGIN_PASS');
  if (missing.length) throw new Error(`Missing required configuration: ${missing.join(', ')}`);
}

module.exports = { config, validateConfig };
