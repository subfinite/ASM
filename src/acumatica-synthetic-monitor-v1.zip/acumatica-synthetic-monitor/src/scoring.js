function score(actualMs, goodMs, badMs) {
  if (actualMs <= goodMs) return 100;
  if (actualMs >= badMs) return 0;
  const pct = 1 - ((actualMs - goodMs) / (badMs - goodMs));
  return Math.round(pct * 100);
}

function calculateScores(timings, scoringConfig) {
  return {
    experienceScore: score(timings.totalTimeMs, scoringConfig.experienceGoodMs, scoringConfig.experienceBadMs),
    loginScore: score(timings.loginSubmitMs, scoringConfig.loginGoodMs, scoringConfig.loginBadMs),
    appScore: score(timings.appLoadMs, scoringConfig.appGoodMs, scoringConfig.appBadMs),
    uiScore: score(timings.uiReadyMs, scoringConfig.uiGoodMs, scoringConfig.uiBadMs)
  };
}

module.exports = { score, calculateScores };
