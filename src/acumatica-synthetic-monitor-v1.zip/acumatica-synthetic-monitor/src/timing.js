async function timeStep(name, fn, timings, logger) {
  const start = Date.now();
  const result = await fn();
  const duration = Date.now() - start;
  timings[name] = duration;
  if (logger) logger.info(`${name}: ${duration}ms`);
  return result;
}

function sleep(ms) { return new Promise((resolve) => setTimeout(resolve, ms)); }

module.exports = { timeStep, sleep };
