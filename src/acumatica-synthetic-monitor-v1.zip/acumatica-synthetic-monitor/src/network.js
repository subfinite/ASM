function attachNetworkCapture(page) {
  const responses = [];
  const consoleErrors = [];

  page.on('response', (response) => {
    try {
      responses.push({ url: response.url(), status: response.status(), time: Date.now() });
    } catch (_) {}
  });
  page.on('console', (msg) => {
    if (msg.type() === 'error') consoleErrors.push({ text: msg.text(), time: Date.now() });
  });
  page.on('pageerror', (err) => {
    consoleErrors.push({ text: err.message, time: Date.now() });
  });
  return { responses, consoleErrors };
}

function summarizeNetwork(capture) {
  return {
    requestCount: capture.responses.length,
    failedRequestCount: capture.responses.filter((r) => r.status >= 400).length,
    consoleErrorCount: capture.consoleErrors.length
  };
}

module.exports = { attachNetworkCapture, summarizeNetwork };
