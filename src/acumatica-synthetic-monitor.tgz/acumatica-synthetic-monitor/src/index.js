const http = require('http');
const pkg = require('../package.json');

const { config, validateConfig } = require('./config');
const { runSynthetic } = require('./runner');
const logger = require('./logger');

let lastMetrics = '';
let lastRunStatus = {
  success: false,
  running: false,
  lastStartedAt: null,
  lastFinishedAt: null,
  lastError: null
};

let lastRunDurationSeconds = 0;
let activeRun = null;

process.on('unhandledRejection', (err) => {
  logger.error('Unhandled rejection', err);
});

try {
  validateConfig();
} catch (err) {
  logger.error(err.message);
  process.exit(1);
}

function appendRuntimeMetrics(metrics) {
  const runningValue = lastRunStatus.running ? 1 : 0;

  const lastFinished = lastRunStatus.lastFinishedAt
    ? Math.floor(new Date(lastRunStatus.lastFinishedAt).getTime() / 1000)
    : 0;

  const cacheAgeSeconds = lastRunStatus.lastFinishedAt
    ? Math.floor((Date.now() - new Date(lastRunStatus.lastFinishedAt).getTime()) / 1000)
    : 0;

  return [
    metrics,
    '# HELP asm_run_in_progress Whether ASM is currently running a synthetic journey',
    '# TYPE asm_run_in_progress gauge',
    `asm_run_in_progress ${runningValue}`,

    '# HELP asm_last_finished_timestamp_seconds Unix timestamp of last completed ASM run',
    '# TYPE asm_last_finished_timestamp_seconds gauge',
    `asm_last_finished_timestamp_seconds ${lastFinished}`,

    '# HELP asm_cached_metrics_age_seconds Age of cached ASM metrics in seconds',
    '# TYPE asm_cached_metrics_age_seconds gauge',
    `asm_cached_metrics_age_seconds ${cacheAgeSeconds}`,

    '# HELP asm_run_duration_seconds Total duration of an ASM synthetic run',
    '# TYPE asm_run_duration_seconds gauge',
    `asm_run_duration_seconds ${lastRunDurationSeconds.toFixed(3)}`

  ].join('\n');
}

async function getMetrics() {
  const collectionStart = Date.now();
  if (activeRun) {
    logger.info('Metrics requested while run is already in progress; returning cached metrics');

    if (lastMetrics) {
      return appendRuntimeMetrics(lastMetrics);
    }

    return [
      '# HELP asm_run_in_progress Whether ASM is currently running a synthetic journey',
      '# TYPE asm_run_in_progress gauge',
      'asm_run_in_progress 1'
    ].join('\n');
  }
  logger.info('Starting new ASM synthetic run');

  lastRunStatus.running = true;
  lastRunStatus.lastStartedAt = new Date().toISOString();
  lastRunStatus.lastError = null;

  activeRun = runSynthetic(config);

  try {
    lastMetrics = await activeRun;
    const collectionDurationSeconds = ((Date.now() - collectionStart) / 1000);
    logger.info(
    `ASM run duration: ${collectionDurationSeconds.toFixed(3)} seconds`
    );
    lastRunDurationSeconds = collectionDurationSeconds;
    lastRunStatus.success = true;
    return appendRuntimeMetrics(lastMetrics);

  } catch (err) {
    lastRunStatus.success = false;
    lastRunStatus.lastError = err.message;
    logger.error('Synthetic run failed from index', err);

    if (lastMetrics) {
      return appendRuntimeMetrics(lastMetrics);
    }

    return '# HELP asm_last_run_success Whether the last ASM run succeeded\n# TYPE asm_last_run_success gauge\nasm_last_run_success 0';
  } finally {
    lastRunStatus.running = false;
    lastRunStatus.lastFinishedAt = new Date().toISOString();
    activeRun = null;
  }
}

http.createServer(async (req, res) => {
  if (req.url === '/') {
    res.writeHead(200, { 'Content-Type': 'text/plain' });
    res.end('ASM OK\n');
    return;
  }

  if (req.url === '/health') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify(lastRunStatus, null, 2));
    return;
  }

  if (req.url === '/version') {
    res.writeHead(200, { 'Content-Type': 'application/json' });
    res.end(JSON.stringify({
      product: 'Acumatica Synthetic Monitor',
      shortName: 'ASM',
      version: pkg.version,
      node: process.version
    }, null, 2));
    return;
  }

  if (req.url !== '/metrics') {
    res.writeHead(404, { 'Content-Type': 'text/plain' });
    res.end('Not found\n');
    return;
  }

  try {
    logger.info(`Metrics request from ${req.socket.remoteAddress} user-agent=${req.headers['user-agent'] || 'unknown'}`);
    const metrics = await getMetrics();
    res.writeHead(200, { 'Content-Type': 'text/plain; version=0.0.4' });
    res.end(metrics + '\n');
  } catch (err) {
    logger.error('Unexpected /metrics failure', err);
    res.writeHead(500, { 'Content-Type': 'text/plain' });
    res.end('ASM metrics collection failed\n');
  }
}).listen(config.port, () => {
  logger.info(`ASM listening on port ${config.port}`);
});

