const path = require('path');
const fs = require('fs');
const { launchBrowser } = require('./browser');
const { attachNetworkCapture, summarizeNetwork } = require('./network');
const { loginToAcumatica } = require('./login');
const { calculateScores } = require('./scoring');
const { timeStep } = require('./timing');
const { PrometheusBuilder } = require('./prometheus');
const logger = require('./logger');
const homeJourney = require('../journeys/home');

async function takeScreenshot(page, screenshotConfig, name) {
  fs.mkdirSync(screenshotConfig.directory, { recursive: true });
  const file = path.join(screenshotConfig.directory, `${name}-${new Date().toISOString().replace(/[:.]/g, '-')}.png`);
  await page.screenshot({ path: file, fullPage: true });
  logger.info(`Screenshot saved: ${file}`);
}

async function runSynthetic(config) {
  let browser;
  const totalStart = Date.now();
  const timings = {};
  const labels = { target: config.acumatica.targetUrl, journey: homeJourney.name };

  try {
    browser = await launchBrowser();
    const page = await browser.newPage();
    const networkCapture = attachNetworkCapture(page);
    const timingContext = { timings, timeStep };

    await loginToAcumatica(page, config.acumatica, timingContext, logger);
    const journeyResult = await homeJourney.run(page, config.acumatica, timingContext, logger);

    timings.totalTimeMs = Date.now() - totalStart;
    const scores = calculateScores(timings, config.scoring);
    const network = summarizeNetwork(networkCapture);

    if (config.screenshots.debug) await takeScreenshot(page, config.screenshots, 'debug-home');

    const prom = new PrometheusBuilder(labels);
    prom.gauge('asm_last_run_success', 'Whether the last ASM run succeeded', 1);
    prom.gauge(
      'asm_last_run_info',
      'Metadata about the last completed ASM run',
      1,
      {
        ready_selector: journeyResult.readySelector || 'unknown',
        ready_frame: journeyResult.readyFrame || 'unknown'
      }
    );
    prom.gauge('asm_experience_score', 'Overall user experience score from 0 to 100', scores.experienceScore);
    prom.gauge('asm_login_score', 'Diagnostic login score from 0 to 100', scores.loginScore);
    prom.gauge('asm_app_score', 'Diagnostic application load score from 0 to 100', scores.appScore);
    prom.gauge('asm_ui_score', 'Diagnostic UI readiness score from 0 to 100', scores.uiScore);
    prom.gauge('asm_total_time_ms', 'Total end-to-end synthetic journey time', timings.totalTimeMs);
    prom.gauge('asm_login_page_load_ms', 'Login page load time', timings.loginPageLoadMs);
    prom.gauge('asm_login_fill_ms', 'Login form fill time', timings.loginFillMs);
    prom.gauge('asm_login_submit_ms', 'Login submit and authentication time', timings.loginSubmitMs);
    prom.gauge('asm_app_load_ms', 'Application load time', timings.appLoadMs);
    prom.gauge('asm_ui_ready_ms', 'UI readiness time', timings.uiReadyMs);
    prom.gauge('asm_frame_count', 'Number of browser frames detected', journeyResult.frameCount);
    prom.gauge('asm_request_count', 'HTTP response count observed by the browser', network.requestCount);
    prom.gauge('asm_failed_request_count', 'HTTP responses with status code >= 400', network.failedRequestCount);
    prom.gauge('asm_console_error_count', 'Browser console errors and page errors', network.consoleErrorCount);
    prom.gauge(
      'asm_total_byte_weight_bytes',
      'Total downloaded byte weight observed from HTTP content-length headers',
      network.totalByteWeightBytes
    );

    prom.gauge(
      'asm_total_byte_weight_mb',
      'Total downloaded megabytes observed from HTTP content-length headers',
      network.totalByteWeightMb
    );
    return prom.output();
  } catch (err) {
    logger.error('Synthetic run failed', err);
    if (browser && config.screenshots.onFailure) {
      try {
        const pages = await browser.pages();
        if (pages[0]) await takeScreenshot(pages[0], config.screenshots, 'failure');
      } catch (screenshotErr) {
        logger.error('Failed to save failure screenshot', screenshotErr);
      }
    }
    const prom = new PrometheusBuilder(labels);
    prom.gauge('asm_last_run_success', 'Whether the last ASM run succeeded', 0);
    return prom.output();
  } finally {
    if (browser) {
    try {
      await browser.close();
    } catch (err) {
      logger.error('Error closing browser', err);

      try {
        const proc = browser.process?.();

        if (proc && !proc.killed) {
          logger.warn('Force killing Chromium process...');
          proc.kill('SIGKILL');
        }
      } catch (killErr) {
        logger.error('Unable to kill Chromium process', killErr);
      }
    }
  }
}
}
module.exports = { runSynthetic };
