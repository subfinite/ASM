function attachNetworkCapture(page) {
  const responses = [];
  const consoleErrors = [];

  page.on('response', async (response) => {
    try {
      const headers = response.headers();

      let bytes = 0;

      if (headers['content-length']) {
        bytes = parseInt(headers['content-length'], 10) || 0;
      }

      responses.push({
        url: response.url(),
        status: response.status(),
        bytes,
        time: Date.now()
      });
    } catch (_) {
      // Ignore response parsing issues.
    }
  });

  page.on('console', (msg) => {
    if (msg.type() === 'error') {
      consoleErrors.push({
        text: msg.text(),
        time: Date.now()
      });
    }
  });

  page.on('pageerror', (err) => {
    consoleErrors.push({
      text: err.message,
      time: Date.now()
    });
  });

  return {
    responses,
    consoleErrors
  };
}

function summarizeNetwork(capture) {
  const totalBytes = capture.responses.reduce((sum, r) => {
    return sum + (r.bytes || 0);
  }, 0);

  return {
    requestCount: capture.responses.length,
    failedRequestCount: capture.responses.filter((r) => r.status >= 400).length,
    consoleErrorCount: capture.consoleErrors.length,
    totalByteWeightBytes: totalBytes,
    totalByteWeightMb: totalBytes / 1024 / 1024
  };
}

module.exports = { attachNetworkCapture, summarizeNetwork };

