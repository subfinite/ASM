const { sleep } = require('../src/timing');

async function waitForSelectorInAnyFrame(page, selectors, options, logger) {
  const selectorList = Array.isArray(selectors) ? selectors : [selectors];

  for (const selector of selectorList) {
    for (const frame of page.frames()) {
      try {
        const element = await frame.waitForSelector(selector, {
          timeout: 2000,
          visible: options.visible
        });

        if (element) {
          logger.info(`Ready selector matched: ${selector}`);
          logger.info(`Ready selector frame: ${frame.url()}`);

          return {
            selector,
            frame,
            url: frame.url()
          };
        }
      } catch (_) {
        // Try next frame/selector.
      }
    }
  }

  throw new Error(`No ready selector found. Tried: ${selectorList.join(', ')}`);
}

async function runHomeJourney(page, config, timing, logger) {
  await timing.timeStep('appLoadMs', async () => {
    await page.goto(config.targetUrl, { waitUntil: 'networkidle2' });
  }, timing.timings, logger);

  let readiness = null;

  await timing.timeStep('uiReadyMs', async () => {
    readiness = await waitForSelectorInAnyFrame(
      page,
      config.readySelectors || config.readySelector,
      {
        visible: config.readySelectorVisible
      },
      logger
    );

    await sleep(config.readyIdleMs);
  }, timing.timings, logger);

  return {
    frameCount: page.frames().length,
    readySelector: readiness ? readiness.selector : 'unknown',
    readyFrame: readiness ? readiness.url : 'unknown'
  };
}

module.exports = {
  name: 'home',
  run: runHomeJourney
};

